FileOverseer !

Fileoverseer is a python script which will organise youe files according to its extension.

How to Use:-

1) Run the Script by double clicking on it
2) It will ask for the path, Just past the path of the folder and hit enter.
3) After hitting enter the script will automatically make the different folders for the different files.

**********************************************************************************************************************

web Site link:-   https://fileoverseer.herokuapp.com
You tube link:-   https://www.youtube.com/channel/UCq6B7DO6vcC2NXgErJ1Bohw

----------------------------------------------------------------------------------------------------------------------

